// Geant4 Libraries
//
#include "G4Step.hh"
#include "G4Track.hh"
#include "G4OpticalPhoton.hh"

#include "G4Event.hh"
#include "G4RunManager.hh"
#include "g4root.hh"
#include "G4SDManager.hh"
#include "G4TransportationManager.hh"
#include "G4SystemOfUnits.hh"

#include "G4UserEventAction.hh"
#include "G4Event.hh"


// Local Libraries
#include "SteppingAction.hh"
#include "DetectorConstruction.hh"
#include "SiPMSD.hh"
#include "SiPMHit.hh"
#include "UserEventAction.hh"

SteppingAction::SteppingAction()
  : G4UserSteppingAction()
{
  G4cout << "...SteppingAction..." << G4endl; 
  G4TransportationManager::GetTransportationManager()
    ->GetNavigatorForTracking()->SetPushVerbosity(0);

  fEventNumber = -1;
  sipmSD = new SiPMSD;
  phoTotal = 0; //total de fotones producidos
  alSiPM = 0; //fotones que llegan al SiPM
  phoOnSiPM = 0; //fotoelectrones generados o fotones detectados por el SiPM
  phoinFiber = 0; //fotones absorbidos por la fibra 
  attScint = 0; //longitud total recorrida por los fotones en el centellador 
  attFiber = 0; //longitud total recorrida por los fotones en la fibra antes de llegar al SiPM y ser detectados
  endFiber = 0;
    waveLength = 0; 
    phoEnergy = 0;
  detectorConstruction 
     = static_cast < const DetectorConstruction* 
     > (G4RunManager::GetRunManager()
         ->GetUserDetectorConstruction());
}

SteppingAction::~SteppingAction()
{}


void SteppingAction::UserSteppingAction(const G4Step* step)
{

  // ==========================
  // Get Track
  G4Track* track = step->GetTrack();

  // ============
  // Get Event Id
  G4int eventNumber                
    = G4RunManager::GetRunManager()
    ->GetCurrentEvent()
    ->GetEventID();
  
  // ============
  // Get Particle Name
  G4String ParticleName 
    = track->GetDynamicParticle()->GetParticleDefinition()->GetParticleName();


  G4AnalysisManager* analysisManager
    = G4AnalysisManager::Instance();


  // ******************************
  // Reset variables for each event
  // ******************************
  if (eventNumber != fEventNumber)
  { analysisManager->FillH1(0,phoTotal);
    //analysisManager->FillH1(2,phoinFiber);
    analysisManager->FillH1(1,alSiPM);
    analysisManager->FillH1(2,phoOnSiPM);
    //analysisManager->FillH1(7,endFiber);
    //analysisManager->FillH1(5,attFiber);
    //analysisManager->FillH1(6,attScint);
    //alysisManager->FillH1(7,waveLength);

    fEventNumber = eventNumber;
    phoTotal = 0; 
    phoOnSiPM = 0;
    sipmSD->resetSiPMSD();
    alSiPM = 0;
    //phoinFiber = 0;
    //attFiber = 0;
    //attScint = 0;
    //endFiber = 0;
    //waveLength = 0; 
    phoEnergy = 0;

  }

  // ***************************
  // Total Scintillation Photons
  // ***************************
 
  if (  track->GetCurrentStepNumber() == 1
        && track->GetDefinition() == G4OpticalPhoton::OpticalPhotonDefinition() 
        && track->GetCreatorProcess()->GetProcessName() == "Scintillation")
	{ phoTotal++;
	 // phoEnergy = track->GetTotalEnergy();
  	//  waveLength = 1240. / (phoEnergy/(1.*eV));
        //  analysisManager->FillH1(7,waveLength);

	}

  // ******************************
  // Total OpWLS Photons (in fiber)
  // ******************************
 
 /* if (  track->GetDefinition() == G4OpticalPhoton::OpticalPhotonDefinition() 
        && track->GetCreatorProcess()->GetProcessName() == "OpWLS" 
        && (step->GetPostStepPoint()->GetPhysicalVolume()->GetName() == "Clad1_1"
	  ||step->GetPostStepPoint()->GetPhysicalVolume()->GetName() == "Clad2_1"
       	  ||step->GetPostStepPoint()->GetPhysicalVolume()->GetName() == "WLSFiber")
      )
	{ phoinFiber++;

		//G4cout << "in fiber " << phoinFiber << G4endl; 
	}*/

  // ******************************
  // Total Photons at the sipm
  // ******************************

	  if ( track->GetDefinition() == G4OpticalPhoton::OpticalPhotonDefinition() 
     	       && step->GetPostStepPoint()->GetPhysicalVolume()->GetName() == "PhotonDet1" )
		  { alSiPM++;
	           
		  if (sipmSD->ProcessHits(step, track->GetGlobalTime()))
			   { phoOnSiPM++;
			    // attFiber = track->GetTrackLength();
			     track->SetTrackStatus(fStopAndKill);
			   }
		 else { track->SetTrackStatus(fStopAndKill); }
		   }

  // ***************************
  // At the end of fiber
  // ***************************

	/*  if ( track->GetDefinition() == G4OpticalPhoton::OpticalPhotonDefinition() 
     	       && step->GetPostStepPoint()->GetPhysicalVolume()->GetName() == "EndFiber" )
		  { //endFiber++;
      	            track->SetTrackStatus(fStopAndKill);


		   }*/



  // ***************************
  // Attenuation in Scintillator
  // ***************************
			
 /* if (  track->GetDefinition() == G4OpticalPhoton::OpticalPhotonDefinition() 
        && step->GetPostStepPoint()->GetPhysicalVolume()->GetName() == "Scintillator1" 
        && step->GetPostStepPoint()->GetProcessDefinedStep()->GetProcessName() == "OpAbsorption")
	{ attScint = track->GetTrackLength();
	  //analysisManager->FillH1(6,attScint);
	} 

*/


  
}


